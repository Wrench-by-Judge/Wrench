export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).end();

  const { jobDescription } = req.body;
  if (!jobDescription) return res.status(400).json({ error: 'Missing jobDescription' });

  const SYSTEM_PROMPT = `You are WRENCH, an AI assistant for tradespeople. Convert raw job descriptions into clean, professional estimates.

Format your response EXACTLY like this (plain text, no markdown):

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESTIMATE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Date: [today's date]
Estimate #: EST-[4 digit random number]

SCOPE OF WORK
[2-3 sentence professional description]

LINE ITEMS
Labor:         [X] hrs @ $[rate]/hr    $[subtotal]
Materials:     [description]           $[amount]
[other line items if applicable]

─────────────────────────────────
Subtotal:                          $[amount]
Tax (8.5%):                        $[amount]
─────────────────────────────────
TOTAL DUE:                         $[amount]
─────────────────────────────────

TERMS
• 50% deposit required to schedule
• Balance due upon completion
• Estimate valid for 30 days
• All work warranted for 1 year

Use realistic labor rates (plumbers $95-130/hr, electricians $100-140/hr, HVAC $90-125/hr, roofers $75-110/hr).
No extra commentary before or after the estimate.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: [{ role: 'user', content: `Generate a professional estimate:\n\n${jobDescription}` }]
      })
    });

    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate estimate' });
  }
}
